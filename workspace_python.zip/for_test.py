# -*- coding: utf-8 -*-
"""
Created on Thu Feb 20 11:58:47 2025

@author: 9000229
"""


fruits = ["apple", "banana", "cherry"]
for fruit in fruits:
    print(fruit)
    

fruits = ["apple", "banana", "cherry"]
for i in range(len(fruits)):  
    print(f"Index {i}: {fruits[i]}")    
    

fruits = ["apple", "banana", "cherry"]
for index, fruit in enumerate(fruits):  
    print(f"Index {index}: {fruit}")
    
    
for index, fruit in enumerate(fruits, start=3):  # 1부터 시작
    print(f"Index {index}: {fruit}")    



names = ["Alice", "Bob", "Charlie"]
ages = [25, 30, 35]

for i, (name, age) in enumerate(zip(names, ages)):
    print(f"Index {i}: {name} is {age} years old.")
    
    
#리스트 컴프리헨션에서도 enumerate()를 활용할 수 있습니다.    
#리스트를 딕셔너리로 변환할 때 유용!
fruits = ["apple", "banana", "cherry"]
fruit_dict = {index: fruit for index, fruit in enumerate(fruits)}
print(fruit_dict)    


#{i:5}	오른쪽 정렬 (기본)
#{i:<5}	왼쪽 정렬
#{i:^5}	가운데 정렬

for i in range(2, 10):  # 2단부터 9단까지 반복
    for j in range(1, 10):  # 각 단의 1~9까지 반복
        print(f"{i:2} x {j} = {i * j}", end=" ")  # 구구단 출력
    print()  # 한 단이 끝나면 줄바꿈
    
    
[print(f"{i} x {j} = {i * j}", end=" " if j < 9 else "\n") for i in range(2, 10) for j in range(1, 10)]

 
   
#만약 출력이 아니라, 구구단을 리스트에 저장하고 싶다면:
gugudan = [f"{i} x {j} = {i * j}" for i in range(2, 10) for j in range(1, 10)]
print("\n".join(gugudan))  # 리스트 내용을 줄 단위로 출력