# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 15:06:43 2025

@author: 9000229
"""
class Calculator:
    def __init__(self):
        self.result = 0

    def add(self, num):
        self.result += num
        return self.result


cal1 = Calculator()
cal2 = Calculator()

print(cal1.add(3))
print(cal1.add(4))
print(cal2.add(3))
print(cal2.add(7))


class FourCal:

    def __init__(self, first, second):
        self.first = first
        self.second = second


    def setdata(self, first, second):
         self.first = first
         self.second = second
    def add(self):
         result = self.first + self.second
         return result
    def mul(self):
         result = self.first * self.second
         return result
    def sub(self):
         result = self.first - self.second
         return result
    def div(self):
         result = self.first / self.second
         return result

class MoreFourCal(FourCal):
    def pow(self):
        result = self.first ** self.second
        return result
     
        
b = FourCal(5, 10)
print(b.add())

a = MoreFourCal(4, 2)
a.pow()



