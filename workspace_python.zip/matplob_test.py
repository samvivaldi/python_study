# -*- coding: utf-8 -*-
"""
Created on Wed Feb 19 11:58:17 2025

@author: 9000229
"""


#선 그래프 (Line Chart)
import matplotlib.pyplot as plt

# 데이터 준비
x = [1, 2, 3, 4, 5]
y = [10, 20, 15, 25, 30]

# 그래프 그리기
plt.plot(x, y, marker='o', linestyle='-', color='b', label="Sales")

# 그래프 제목 및 라벨
plt.title("Simple Line Chart")
plt.xlabel("Days")
plt.ylabel("Sales")
plt.legend()

# 그래프 표시
plt.show()



# 막대 그래프 그리기
import matplotlib.pyplot as plt

# 데이터 준비
categories = ["A", "B", "C", "D"]
values = [40, 60, 80, 30]

# 막대 그래프 그리기
plt.bar(categories, values, color=['red', 'green', 'blue', 'orange'])

# 제목 및 라벨
plt.title("Bar Chart Example")
plt.xlabel("Category")
plt.ylabel("Value")

# 그래프 표시
plt.show()

#원형 그래프 (Pie Chart)
import matplotlib.pyplot as plt

# 데이터 준비
labels = ["Python", "Java", "C++", "JavaScript"]
sizes = [35, 30, 20, 15]
colors = ["gold", "lightblue", "lightcoral", "lightgreen"]

# 원형 그래프 그리기
plt.pie(sizes, labels=labels, autopct="%1.1f%%", colors=colors, startangle=140)

# 제목 추가
plt.title("Programming Language Popularity")

# 그래프 표시
plt.show()


#산점도 (Scatter Plot)
import matplotlib.pyplot as plt
import numpy as np

# 데이터 생성
x = np.random.rand(50)
y = np.random.rand(50)

# 산점도 그리기
plt.scatter(x, y, color="purple", alpha=0.7)


# 제목 및 라벨
plt.title("Scatter Plot Example")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")

# 그래프 표시
plt.show()


