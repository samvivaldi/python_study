# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 09:26:48 2025

@author: 9000229
"""

import os
import datetime
import time
import random
import math
import itertools
import functools

#print(os.getcwd())
#print(os.system("dir"))

#from os import *
#print(system("dir"))

#dir(os)

result = '';

day1 = datetime.date(2021, 12, 14)
day2 = datetime.date(2023, 4, 5)
diff = day2 - day1

print(type(day1))

isinstance(diff, datetime.timedelta)

print(time.localtime(time.time()))
print(time.asctime(time.localtime(time.time())))


resultTime = time.strftime('%Y%m%d %H%M %A %Z', time.localtime(time.time()))
print(resultTime)


#for i in range(10):
#    print(i)
#    time.sleep(1)

random.random()
    
import math
#최대 공약수 파이썬 3.9 버전
result = math.gcd(60, 100, 80, 120)
print(f"{result} is 최대공약수")

#최소 공배수 파이썬 3.9 버전
result = math.lcm(15, 25, 5, 91)
print(f"{result} is 최소 공배수")

students = ['한민서', '황지민', '이영철', '이광수', '김승민']
snacks = ['사탕', '초컬릿', '젤리']

result = zip(students, snacks)
print(list(result))

result = itertools.zip_longest(students, snacks, fillvalue='새우깡')
print(list(result))
dir(itertools)



def add(data):
    result = 0
    for i in data:
        result += i
    return result

data = [1, 2, 3, 4, 5]
result = add(data)
print(result)  # 15 출력

#reduce
# reduce_test.py
import functools

data = [1, 2, 3, 4, 5]
result = functools.reduce(lambda x, y: x + y, data)
print(result)  # 15 출력

#최댓값 구하기
num_list = [3, 2, 8, 1, 6, 7]
max_num = functools.reduce(lambda x, y: x if x > y else y, num_list)
print(max_num)  # 8 출력


from operator import itemgetter

students = [
    ("jane", 22, 'A'),
    ("dave", 32, 'B'),
    ("sally", 17, 'B'),
]

result = sorted(students, key=itemgetter(1))
print(result)

# itemgetter2.py
from operator import itemgetter

students = [
    {"name": "jane", "age": 22, "grade": 'A'},
    {"name": "dave", "age": 32, "grade": 'B'},
    {"name": "sally", "age": 17, "grade": 'B'},
]

result = sorted(students, key=itemgetter('age'))
print(result)

# shutil_copy.py
import shutil

shutil.copy("C:/Users/9000229/PyhtonTestPrj/testFile.txt", "C:/Users/9000229/PyhtonTestPrj/testFile.txt.bak")
dir(shutil)

import glob
result = glob.glob("C:\\Users\\9000229\\PyhtonTestPrj\\*")
print(result)
result = glob.glob("C:/Users/9000229/PyhtonTestPrj/*")
print(result)

'''
pickle은 객체의 형태를 그대로 유지하면서 파일에 저장하고 불러올 수 있게 하는 모듈이다. 다음 예는 pickle 모듈의 dump 함수를 사용하여 딕셔너리 객체인 data를 그대로 파일에 저장하는 방법을 보여 준다.
'''

import pickle
f = open("test2.txt", 'wb')
data = {1: 'python', 2: 'you need'}
pickle.dump(data, f)
f.close()

import pickle
f = open("test2.txt", 'rb')
data = pickle.load(f)
print(data)

import os
os.environ['PATH']
os.getcwd()


# import zipfile

# # 파일 합치기
# with zipfile.ZipFile('mytext.zip', 'w') as myzip:
#     myzip.write('a.txt')
#     myzip.write('b.txt')
#     myzip.write('c.txt')

# # 해제하기
# with zipfile.ZipFile('mytext.zip') as myzip:
#     myzip.extractall()

# 특정 파일만 해제하기
# with zipfile.ZipFile('mytext.zip') as myzip:
#     myzip.extract('a.txt')
