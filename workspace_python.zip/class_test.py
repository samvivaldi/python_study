# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 16:02:30 2025

@author: 9000229
"""

class FourCal:

    first = 0
    second = 0

    def __init__(self, first, second):
        self.first = first
        self.second = second
        FourCal.first = second


    def setdata(self, first, second):
         self.first = first
         self.second = second
    def add(self):
         result = self.first + self.second
         return result
    def mul(self):
         result = self.first * self.second
         return result
    def sub(self):
         result = self.first - self.second
         return result
    def div(self):
         result = self.first / self.second
         return result
     
a = FourCal(3, 4);
print(a.first)


print(FourCal.first)


b = FourCal(3, 99);
print(a.first)
print(FourCal.first)
