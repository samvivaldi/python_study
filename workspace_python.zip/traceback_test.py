# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 10:19:42 2025

@author: 9000229
"""

# traceback_test.py
import traceback

# traceback_test.py
def a():
    return 1/0

def b():
    a()

def main():
    try:
        b()
    except:
        print("오류가 발생했습니다.")
        #print(traceback.format_exc())
        #traceback.print_exc()
       
main()
