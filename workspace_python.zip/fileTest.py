# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 14:44:37 2025

@author: 9000229
"""

f = open('testFile.txt', 'w', encoding="cp949")



for i in range(1, 10):
    data = f"{i}.첫번째 lines.";
    f.write(f"{i}.첫번째 줄입니다.\n")    
    f.write(data + "\n")
f.close()    




f = open('testFile.txt', 'r')


while True:
    line = f.readline()
    if not line: break
    print(line, end= ' ')
f.close()


f = open("testFile.txt", 'r')
for line in f:
    print(line.strip())
f.close()


import sys

