# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 13:54:09 2025

@author: 9000229
"""

a = [1, 2, 3]
#a = iter(a)
for i in a:
    print(i)

for i in a:
    print(i)

def multFn(a, b):
    return a+b, a*b

a = multFn(3, 3)

print(type(a))
print(a)


a=3
def fn1():
   
    if True:
        a= 2
        print(a)
    print(a)

fn1()

print(a)    


a = input("입력해라")

print("life" "is" "too short", a)


for i in range(10):
    print(i, end=' ')




a = [ i * j for i in range(2, 10) for j in range(1, 10)]
print(a)   

for i, value in enumerate(a):
    print(a[i], end= ' ')
    if (i + 1) % 9 == 0:
        print()
        
        

for i in range(0, len(a)):
    print(a[i], end= ' ')
    if (i + 1) % 9 == 0:print()
        

for i in range(2, 10):       
    for j in range(1, 10):   
        print(f"{i}*{j}={i * j:2}", end="\t")
    print('')

for i in range(2, 10):       
    for j in range(1, 10):   
        print("%s*%2s=%2s" %(i, j, i*j), end="\t")
    print('')

print(list(filter(lambda x:x > 1, [-1,-2, 0, 1, 3, 4, 5])))



