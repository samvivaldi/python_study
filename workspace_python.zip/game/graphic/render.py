# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 16:39:21 2025

@author: 9000229
"""

def render_test():
    print("render")