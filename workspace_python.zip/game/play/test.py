# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 16:41:18 2025

@author: 9000229
"""

#import game.sound.echo
#game.sound.echo.echo_test()

#from game.sound import echo
#echo.echo_test()

#from game.sound.echo import echo_test;
#echo_test()

import game
print(game.VERSION)
game.print_version_info()

game.render_test()


"""
뭔가 이상하지 않은가? 분명 game.sound 패키지에서 모든 것(*)을 import했으므로 echo 모듈을 사용할 수 있어야 할 것 같은데, echo라는 이름이 정의되지 않았다는 오류가 발생했다.

이렇게 특정 디렉터리의 모듈을 *를 사용하여 import할 때는 다음과 같이 해당 디렉터리의 __init__.py 파일에 __all__ 변수를 설정하고 import할 수 있는 모듈을 정의해 주어야 한다.

# C:/doit/game/sound/__init__.py
__all__ = ['echo']
여기에서 __all__이 의미하는 것은 sound 디렉터리에서 *를 사용하여 import할 경우, 이곳에 정의된 echo 모듈만 import된다는 의미이다.

착각하기 쉬운데 from game.sound.echo import *은 __all__과 상관없이 import된다. 이렇게 __all__과 상관없이 무조건 import되는 경우는 from a.b.c import *에서 from의 마지막 항목인 c가 모듈인 때이다.
"""

from game.sound import *
echo.echo_test()
