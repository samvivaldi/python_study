# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 16:41:11 2025

@author: 9000229
"""

