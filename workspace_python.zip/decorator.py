# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 15:18:02 2025

@author: 9000229
"""


import time

def elapsed(original_func):   # 기존 함수를 인수로 받는다.
    def wrapper():
        start = time.time()
        result = original_func()    # 기존 함수를 수행한다.
        time.sleep(2)
        end = time.time()
        
        print("함수 수행시간: %f 초" % (end - start))  # 기존 함수의 수행시간을 출력한다.
        return result  # 기존 함수의 수행 결과를 리턴한다.
    return wrapper

def myfunc():
    print("함수가 실행됩니다.")

decorated_myfunc = elapsed(myfunc)
decorated_myfunc()

###########################

@elapsed
def myfuncA():
    print("함수가 실행됩니다 .  @elapsed")
    
myfuncA()

###########################
# 아래 오류 발생 파라메터를 전달할 수 없읍.

@elapsed
def myfunc(msg):
    print("'%s'을 출력합니다." % msg)

myfunc("You need python")  # 출력할 메시지를 myfunc 파라미터로 전달한다.


####################################
"""
*args는 모든 입력 인수를 튜플로 변환하는 매개변수, 
**kwargs는 모든 ‘키=값’ 형태의 입력 인수를 딕셔너리로 변환하는 매개변수이다. 
"""


def elapsed(original_func):   # 기존 합수를 인수로 받는다.
    def wrapper(*args, **kwargs):   # *args, **kwargs 매개변수 추가
        start = time.time()
        result = original_func(*args, **kwargs)  # 전달받은 *args, **kwargs를 입력파라미터로 기존함수 수행
        end = time.time()
        print("함수 수행시간: %f 초" % (end - start))  # 수행시간을 출력한다.
        return result  # 함수의 결과를 리턴한다.
    return wrapper

@elapsed
def myfunc(msg):
    """ 데코레이터 확인 함수 """
    print("'%s'을 출력합니다." % msg)

myfunc("You need python")
