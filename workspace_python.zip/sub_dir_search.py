# -*- coding: utf-8 -*-

"""
Created on Tue Feb 18 15:07:32 2025

@author: 9000229
"""


import os

def search(dirname):
    try:
        filenames = os.listdir(dirname)
        for filename in filenames:
            full_filename = os.path.join(dirname, filename)
            if os.path.isdir(full_filename):
                search(full_filename)
            else:
                ext = os.path.splitext(full_filename)[-1]
                if ext == '.py': 
                    print(full_filename)
    except PermissionError:
        pass

        

search("C:\\Users\\9000229\\PyhtonTestPrj")


for (path, dir, files) in os.walk("C:\\Users\\9000229\\PyhtonTestPrj"):
    for filename in files:
        ext = os.path.splitext(filename)[-1]
        if ext == '.py':
            print("%s/%s" % (path, filename))
            
