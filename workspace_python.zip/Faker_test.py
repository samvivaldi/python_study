# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 13:42:54 2025

@author: 9000229
"""

from faker import Faker


fake = Faker("ko-KR")

dir(fake)

result = fake.name()

print("result is %s" % result)

result = fake.address()

print("result is %s" % result)


result = [(fake.name(), fake.address(), fake.phone_number(), fake.email()) for i in range(30)]
print(f"result is {result}")

