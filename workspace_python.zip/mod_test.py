# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 16:07:50 2025

@author: 9000229
"""

import sys
import mod1
from mod1 import sub
import sam.samTest 

a = mod1.add(3, 10)
print(a)

sub(10, 1)


#print(mod1.__name__)

#print('sys' , sys.path)



sam.samTest.add(3, 3)