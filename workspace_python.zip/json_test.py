# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 10:24:04 2025

@author: 9000229
"""

import json

with open('myinfo.json', encoding='utf-8') as f:
    data = json.load(f)


print(type(data))
print(f"{data}")


data =  json.load(open('myinfo.json', encoding='utf-8'))


d = {"name":"홍길동", "birth":"0525", "age": 30}
json_data = json.dumps(d)

print(f"json_data is {json_data}")


#json_data = json.loads(d)
json_data = json.loads(json_data)
print(type(json_data))

print(f"json.loads(json_data) is {json_data}")


json_data = json.dumps(d, ensure_ascii=False)
print(f" json.dumps(d, ensure_ascii=False) is {json_data}")
print(type(json_data))
