# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 15:49:20 2025

@author: 9000229
"""

def add(a: int, b: int) -> int: 
    return a+b

result = add(3, 3.4)
#result = add(3, 3)
print(result)  # 6.4 출력