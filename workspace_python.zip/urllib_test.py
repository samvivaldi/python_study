# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 10:35:36 2025

@author: 9000229
"""

import urllib.request

# SSL 인증서 검증을 비활성화하는 Context 생성
import ssl
context = ssl._create_unverified_context()

def get_wikidocs(page):
    resource = f'https://wikidocs.net/{page}'
    with urllib.request.urlopen(resource, context=context) as s:  # 생성한 Context 전달
        with open(f'wikidocs_{page}.html', 'wb') as f:
            f.write(s.read())

get_wikidocs(12)
