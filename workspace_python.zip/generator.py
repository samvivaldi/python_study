# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 15:36:12 2025

@author: 9000229
"""

def mygen():
    for i in range(1, 1000):
        result = i * i
        yield result

gen = mygen()
print(next(gen))
print(next(gen))
print(next(gen))


gen = (i * i for i in range(1, 1000))

print(next(gen))
print(next(gen))
print(next(gen))
print(next(gen))


class MyIterator:
    def __init__(self):
        self.data = 1

    def __iter__(self):
        return self

    def __next__(self):
        result = self.data * self.data
        self.data += 1
        if self.data >= 1000:
            raise StopIteration
        return result
    
num: int = 1
    