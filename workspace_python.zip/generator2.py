# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 15:38:59 2025

@author: 9000229
"""

import time

def longtime_job():
    print("job start")
    time.sleep(1)  # 1초 지연
    return "done"

list_job = [longtime_job() for i in range(5)]
#print(list_job)

print(list_job)


#################

import time

def longtime_job():
    print("job start")
    time.sleep(1)
    return "done"

list_job = (longtime_job() for i in range(5))
print(list_job)

print(next(list_job))


"""
[longtime_job() for i in range(5)] 코드를 제너레이터 표현식(longtime_job() for i in range(5))으로 
바꾸었을 뿐이다. 그런데 실행 시 1초의 시간만 소요되고 출력되는 결과도 전혀 다르다.

job start
done
왜냐하면 제너레이터 표현식으로 인해 longtime_job() 함수가 5회가 아닌 1회만 호출되기 때문이다

"""


for i in range(2, 10):  # 2단부터 9단까지 반복
    for j in range(1, 10):  # 각 단의 1~9까지 반복
        print(f"{i} x {j} = {i * j}", end=" ")  # 구구단 출력
    print()  # 한 단이 끝나면 줄바꿈