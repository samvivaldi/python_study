#
print("Initializing game ...")