# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 15:52:20 2025

@author: 9000229
"""

import re

data = """
park 800905-1049118
kim  700905-1059119
"""



a = re.match("(\\d{6})[-]\\d{7}", "800905-1049118")
print("re.match", a)
print("a.group(1)", a.group(1))
print("a.lastindex", a.lastindex)


pat = re.compile("(\\d{6})[-]\\d{7}")
print("pat", pat)

print(pat.sub("\\g<1>-*******", data))